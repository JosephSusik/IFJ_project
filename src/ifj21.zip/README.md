# IFJ_project
Project for IFJ
